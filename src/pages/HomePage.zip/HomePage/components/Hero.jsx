import { motion, useScroll, useTransform, useMotionValue, useSpring } from "framer-motion";
import { useState, useEffect, useRef, useCallback } from "react";
import styles from "./styles/Hero.module.css";

const PARTICLES = Array.from({ length: 55 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,
  y: Math.random() * 100,
  size: Math.random() * 3 + 1,
  duration: Math.random() * 8 + 6,
  delay: Math.random() * 5,
  opacity: Math.random() * 0.5 + 0.2,
}));

const WORDS = ["Weddings", "Celebrations", "Galas", "Anniversaries", "Milestones"];

export default function Hero() {
  const [wordIndex, setWordIndex] = useState(0);
  const [displayedWord, setDisplayedWord] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const heroRef = useRef(null);
  const cursorX = useMotionValue(0);
  const cursorY = useMotionValue(0);
  const springX = useSpring(cursorX, { stiffness: 80, damping: 20 });
  const springY = useSpring(cursorY, { stiffness: 80, damping: 20 });

  const { scrollYProgress } = useScroll({ target: heroRef });
  const yBg = useTransform(scrollYProgress, [0, 1], ["0%", "40%"]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.55], [1, 0]);
  const contentScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.88]);

  const handleMouseMove = useCallback((e) => {
    const rect = heroRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 25;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 25;
    cursorX.set(x);
    cursorY.set(y);
  }, [cursorX, cursorY]);

  useEffect(() => {
    const word = WORDS[wordIndex];
    let timeout;
    if (!isDeleting && displayedWord.length < word.length) {
      timeout = setTimeout(() => setDisplayedWord(word.slice(0, displayedWord.length + 1)), 110);
    } else if (!isDeleting && displayedWord.length === word.length) {
      timeout = setTimeout(() => setIsDeleting(true), 2200);
    } else if (isDeleting && displayedWord.length > 0) {
      timeout = setTimeout(() => setDisplayedWord(displayedWord.slice(0, -1)), 55);
    } else {
      setIsDeleting(false);
      setWordIndex((i) => (i + 1) % WORDS.length);
    }
    return () => clearTimeout(timeout);
  }, [displayedWord, isDeleting, wordIndex]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.18, delayChildren: 0.5 } },
  };

  const itemVariants = {
    hidden: { y: 80, opacity: 0, filter: "blur(12px)" },
    visible: { y: 0, opacity: 1, filter: "blur(0px)", transition: { duration: 1.1, ease: [0.16, 1, 0.3, 1] } },
  };

  return (
    <section className={styles.hero} id="hero" ref={heroRef} onMouseMove={handleMouseMove}>
      <motion.div className={styles.orb1} style={{ x: springX, y: springY }} />
      <motion.div className={styles.orb2} style={{ x: springX, y: springY }} />
      <motion.div className={styles.orb3} />
      <motion.div className={styles.heroParallax} style={{ y: yBg }} />
      <div className={styles.gridOverlay} />
      <div className={styles.noiseOverlay} />

      {PARTICLES.map((p) => (
        <motion.div
          key={p.id}
          className={styles.particle}
          style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.size, height: p.size }}
          animate={{ y: [0, -45, 0], opacity: [p.opacity * 0.2, p.opacity, p.opacity * 0.2], scale: [1, 1.6, 1] }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}

      <motion.div
        className={styles.heroContent}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        style={{ opacity: contentOpacity, scale: contentScale }}
      >
        <motion.div variants={itemVariants} className={styles.heroEyebrow}>
          <span className={styles.eyebrowLine} />
          <span>Welcome to Elegance</span>
          <span className={styles.eyebrowLine} />
        </motion.div>

        <motion.h1 variants={itemVariants} className={styles.heroTitle}>
          <span className={styles.titleTop}>Vidhi</span>
          <span className={styles.titleBottom}>Vidhan</span>
        </motion.h1>

        <motion.div variants={itemVariants} className={styles.typewriterWrapper}>
          <span className={styles.typewriterPrefix}>Crafting </span>
          <span className={styles.typewriterText}>{displayedWord}</span>
          <motion.span
            className={styles.cursor}
            animate={{ opacity: [1, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, repeatType: "reverse" }}
          >|</motion.span>
        </motion.div>

        <motion.p variants={itemVariants} className={styles.heroDescription}>
          Transforming dreams into magnificent realities — one celebration at a time
        </motion.p>

        <motion.div variants={itemVariants} className={styles.heroActions}>
          <motion.button
            className={styles.primaryButton}
            whileHover={{ scale: 1.06, boxShadow: "0 0 60px rgba(255,215,0,0.5), 0 20px 40px rgba(0,0,0,0.4)" }}
            whileTap={{ scale: 0.97 }}
          >
            <span>Explore Our Work</span>
            <motion.span
              className={styles.btnArrow}
              animate={{ x: [0, 6, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >→</motion.span>
          </motion.button>

          <motion.button
            className={styles.secondaryButton}
            whileHover={{ scale: 1.05, backgroundColor: "rgba(255,215,0,0.06)" }}
            whileTap={{ scale: 0.97 }}
          >
            <span className={styles.playIcon}>▶</span>
            Watch Story
          </motion.button>
        </motion.div>

        <motion.div variants={itemVariants} className={styles.heroStats}>
          {[["500+", "Events Done"], ["10+", "Years"], ["10K+", "Happy Clients"]].map(([num, label]) => (
            <motion.div
              key={label}
              className={styles.miniStat}
              whileHover={{ y: -4, borderColor: "rgba(255,215,0,0.5)" }}
              transition={{ duration: 0.25 }}
            >
              <span className={styles.miniStatNum}>{num}</span>
              <span className={styles.miniStatLabel}>{label}</span>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>

      <motion.div
        className={styles.scrollIndicator}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2 }}
      >
        <motion.div
          className={styles.scrollMouse}
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.8, repeat: Infinity }}
        >
          <div className={styles.scrollDot} />
        </motion.div>
        <span>Scroll</span>
      </motion.div>
    </section>
  );
}
